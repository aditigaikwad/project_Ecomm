function updateUser(value)
				{
				
				window.location="update_query.php?update="+value;
				alert(value +"is Deactivated");
				}
				
function updateUser1(value)
				{
				
				window.location="update1_query.php?update="+value;
				alert(value +"is Activated");
				}
