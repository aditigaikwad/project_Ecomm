<tr>
		<td colspan="4"><h4 style="color:DarkRed;text-align:center">Total Price</h4></td>
		<td><h4 style="color:DarkRed;text-align:center"><?php  echo $price;?></h4></td>