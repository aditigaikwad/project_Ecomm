<?php
include_once "HeaderHtml.php";
include_once "BodyHome.php";
include_once "html/FooterHtml.html";
