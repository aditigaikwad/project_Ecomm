<thead>
		<tr>
			<th width="13%"><font face="BedRock" color="DarkSlateGray">Product Name</th>
			<th width="10%"><font face="BedRock" color="DarkSlateGray">Price</th>
			<th width="15%"><font face="BedRock" color="DarkSlateGray">Image Name</th>
			<th width="35"><font face="BedRock" color="DarkSlateGray">Image</th>
			<th width="27%"><font face="BedRock" color="DarkSlateGray">Description </th>
		</tr>
	</thead>