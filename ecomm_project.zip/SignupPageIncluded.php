<?php
session_start();
include_once "HeaderHtml.php";
include_once "html/BodySignupHtml.html";
include_once "html/FooterHtml.html";
