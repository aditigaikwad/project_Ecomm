<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<?php header("location:html/loginAdmin.html");?>
</body>
</html>
